# Color Detection from Images

This project extracts the top 3 dominant colors from images and stores the result in a CSV file.

## How to Use

1. Place images in the `images/` folder.
2. Run the script: `python color_detection.py`
3. Check `colors.csv` for results.

## Requirements

- OpenCV
- scikit-learn
- pandas

Install dependencies:
```
pip install opencv-python scikit-learn pandas
```
